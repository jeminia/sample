package com.tnagata.demo.service;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tnagata.demo.db.entity.Member;
import com.tnagata.demo.db.repository.MemberRepository;

/**
 * 会員情報サービスクラス
 *
 * @author tnagata
 * @version 1.0
 */
@Service
public class MemberService {


	@Autowired
	private MemberRepository memberRepository;

	@Autowired
	private SqlSession sqlSession;

//	@Autowired
//	private MemberDao memberDao;


	public List<Member> getMemberAll () {

		return memberRepository.findAll();
	}


	/**
	 * 主キーよりサンプルテーブルを検索
	 *
	 * @param id
	 * @return
	 */
	public List<Member> selectOneByPrimaryKey (int id) {

		return sqlSession.selectOne("member.selectMember");
		//return memberDao.selectOne("aaa@example.com");
	}


	public void save () {

		Member member = new Member();
		Date sysDate = new Date();

		member.setEmail("bbb@example.com");
		member.setPassword("password");
		member.setEnable(true);
		member.setCreateUser("root");
		member.setCreateDate(sysDate);
		member.setUpdateUser("root");
		member.setUpdateDate(sysDate);

		memberRepository.save(member);

	}
}
