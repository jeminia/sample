package com.tnagata.demo.db.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 会員情報テーブルエンティティクラス(サンプル)
 *
 * @author tnagata
 *
 */
@Entity
@Table(name="tbl_t_member")
public class Member implements Serializable {

	@Id
	@Column(name="email")
	/** E-Mailアドレス */
	private String email;

	/** パスワード */
	@Column(name="password")
	private String password;

	/** 有効フラグ */
	@Column(name="enable")
	private boolean enable;

	/** 作成者 */
	@Column(name="create_user")
	private String createUser;

	/** 作成日 */
	@Column(name="create_date")
	private Date createDate;

	/** 更新者 */
	@Column(name="update_user")
	private String updateUser;

	/** 更新日 */
	@Column(name="update_date")
	private Date updateDate;

	/** 削除日 */
	@Column(name="delete_date")
	private Date deleteDate;

	/**
	 * 空のコンストラクタ
	 */
	public Member(){

	}

	public Member(String email,
			      String password,
			      boolean enable,
			      String createUser,
			      Date createDate,
			      String updateUser,
			      Date updateDate,
			      Date deleteDate){
		this.email = email;
		this.password = password;
		this.enable = enable;
		this.createDate = createDate;
		this.updateUser = updateUser;
		this.updateDate = updateDate;
		this.deleteDate = deleteDate;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public boolean isEnable() {
		return enable;
	}

	public void setEnable(boolean enable) {
		this.enable = enable;
	}

	public String getCreateUser() {
		return createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	public Date getDeleteDate() {
		return deleteDate;
	}

	public void setDeleteDate(Date deleteDate) {
		this.deleteDate = deleteDate;
	}
}
