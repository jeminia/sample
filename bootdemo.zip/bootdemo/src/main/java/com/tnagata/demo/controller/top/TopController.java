package com.tnagata.demo.controller.top;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * トップページ遷移用Controller
 *
 * @author tnagata
 *
 */
@Controller
@EnableAutoConfiguration
public class TopController {

	@RequestMapping(value="/top", method=RequestMethod.POST)
	public String top (Model model) {

		return "top";
	}

	@RequestMapping(value="/top", method=RequestMethod.GET)
	public String topGet (Model model) {

		return "top";
	}
}
