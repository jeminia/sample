package com.tnagata.demo.controller.login;

public class LoginController {

}
