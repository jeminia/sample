package com.tnagata.demo.db.data;

import org.springframework.stereotype.Component;

@Component
public class MemberDao {



}
