package com.tnagata.demo.controller.member;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.tnagata.demo.db.entity.Member;
import com.tnagata.demo.service.MemberService;

@Controller
@EnableAutoConfiguration
public class MemberRestService {

	protected Log log = LogFactory.getFactory().getInstance(this.getClass().getName());


	@Autowired
	MemberService memberService;

	@RequestMapping(value="/getMember", method=RequestMethod.GET)
	public String getMember() {

		log.info("会員情報取得開始");

		//List<Member> memberList = memberService.getMemberAll();

		List<Member> memberList = memberService.selectOneByPrimaryKey(1);

		log.info("会員情報取得終了");

		return "top";
	}

	@RequestMapping(value="/saveMember", method=RequestMethod.GET)
	public String saveMember() {

		memberService.save();

		return "top";
	}
}
