package com.tnagata.demo.db.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.tnagata.demo.db.entity.Member;

@Repository
public interface MemberRepository extends JpaRepository <Member, String>{

	/** 全件取得 */
	//List<Member> findAll ();

	//List<Member> findByEmail ();

	/** クエリー実行により取得 */
	//List<Member> findByQuery ();

}
