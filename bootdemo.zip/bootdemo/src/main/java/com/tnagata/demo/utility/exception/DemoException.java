package com.tnagata.demo.utility.exception;

/**
 * サンプルプロジェクトエラークラス
 *
 * @author tnagata
 *
 */
public class DemoException extends Exception {

}
